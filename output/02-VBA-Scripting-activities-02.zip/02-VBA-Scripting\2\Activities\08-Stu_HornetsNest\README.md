# Hornets Nest

## Instructions

* Create a VBA script to handle the growing Hornet infestation in your spreadsheet.

* There are three parts to this problem:

  * Part I: Count the number of Hornets found and display the number to your user in the form of a message box.

  * Part II: Modify the script such that it changes the word Hornets to "Bugs".

  * Part III: Modify the script a third time, this time keeping in mind that you have a limited number of Bugs and Bees. Use the full set of Bugs and Bees you have available to replace the Hornets. If you run out of Bugs or Bees provide the user with the message: "Oh no! We still have hornets..."

## Hints

* You may want to create a backup of your spreadsheet as your macro will write over the contents.

* Take lots of deep breaths!
