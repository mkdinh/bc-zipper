# Sentence Breaker

## Instructions

* Using the files provided as a starting point, create a VBA script such that it reads in a User Sentence then prints the correct words based on word numbers provided.

## Notes

* This is a more challenging assignment. So take your time on it. Try to bite it off bit by bit.
