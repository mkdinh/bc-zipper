# Miles Per Gallon

## Instructions

* Create a scatter plot using the data provided, Pandas, and MatplotLib which compares the MPG of a vehicle with its horsepower.
