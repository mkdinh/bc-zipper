# Filtered Roster Check

## Instructions

* Given a roster of players, determine which players have made the team and which have not, using `filter()`.

* Print out all players who have made the team.

* Print out the number of players who made the team, and of players who did not.
