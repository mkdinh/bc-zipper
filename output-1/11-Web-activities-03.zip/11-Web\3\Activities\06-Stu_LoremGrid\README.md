# Lorem Grid

* In this activity we will attempt to recreate a layout using the Bootstrap grid system.

## Instructions

* Open [`04-Lorem-Grid.png`](Images/04-Lorem-Grid.png) file located within the [`Images`](Images) folder.

* Take a moment to study the image and create this layout using Bootstrap grid.

* You can use [lorem ipsum](http://www.lipsum.com/) for the text.

* You can read about the grid system here: <http://getbootstrap.com/css/#grid>

## Hints

* Container > Row > Column
